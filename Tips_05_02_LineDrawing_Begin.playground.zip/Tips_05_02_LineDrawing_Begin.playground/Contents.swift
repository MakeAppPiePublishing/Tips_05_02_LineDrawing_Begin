import UIKit
import PlaygroundSupport

class View:UIView{
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.frame = frame
        backgroundColor = UIColor(white: 0.85, alpha: 1.0)
        drawLines()
    }
    func drawLines(){
        let drawPoints:[CGPoint] = [CGPoint(x: 300, y:300),CGPoint(x: 300, y: 500),CGPoint(x: 500, y: 500),CGPoint(x: 500, y: 300)]
        let imagerenderer = UIGraphicsImageRenderer(size: frame.size)
        let image = imagerenderer.image(actions:  { (context) in
            //#-editable-code
            //Place drawing code here
            
            //#-end-editable-code
        })
        let imageView = UIImageView(image: image)
        addSubview(imageView)
    }
}

PlaygroundPage.current.liveView = View.init(frame: UIScreen.main.bounds)
